---
title: Speaker
categories:
  - Devices
tags:
  - audio
  - sound
---
