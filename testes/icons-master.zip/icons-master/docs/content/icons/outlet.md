---
title: Outlet
categories:
  - Real world
tags:
  - plug
  - power
---
