---
title: Star
categories:
  - Shapes
tags:
  - shape
  - like
  - favorite
---
