---
title: Octagon half
categories:
  - Shapes
tags:
  - shape
  - polygon
---
