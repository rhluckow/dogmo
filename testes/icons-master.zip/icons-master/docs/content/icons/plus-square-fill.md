---
title: Plus square fill
categories:
  - Alerts, warnings, and signs
tags:
  - add
  - new
---
