---
title: Plus circle fill
categories:
  - Alerts, warnings, and signs
tags:
  - add
  - new
---
