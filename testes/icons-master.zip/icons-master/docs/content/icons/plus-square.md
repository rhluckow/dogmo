---
title: Plus square
categories:
  - Alerts, warnings, and signs
tags:
  - add
  - new
---
