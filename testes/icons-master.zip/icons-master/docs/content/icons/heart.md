---
title: Heart
categories:
  - Shapes
tags:
  - love
  - favorite
---
