---
title: Alert triangle
categories:
  - Alerts, warnings, and signs
tags:
  - alert
  - warning
---
