---
title: Slash square fill
categories:
  - Alerts, warnings, and signs
tags:
  - shape
  - stop
  - ban
  - no
---
