---
title: Question diamond
categories:
  - Alerts, warnings, and signs
tags:
  - help
---
