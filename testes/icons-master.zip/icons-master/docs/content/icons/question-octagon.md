---
title: Question octagon
categories:
  - Alerts, warnings, and signs
tags:
  - help
---
