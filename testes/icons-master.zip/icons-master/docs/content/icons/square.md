---
title: Square
categories:
  - Shapes
tags:
  - shape
  - rectangle
---
