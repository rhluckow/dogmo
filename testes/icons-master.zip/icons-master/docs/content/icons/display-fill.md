---
title: Display fill
categories:
  - Devices
tags:
  - monitor
  - external
---
