---
title: Skip backward
categories:
  - Media
tags:
  - audio
  - video
  - av
---
