---
title: Tablet
categories:
  - Devices
tags:
  - mobile
---
