---
title: Dash square fill
categories:
  - UI and keyboard
tags:
  - minus
---
