---
title: Shift fill
categories:
  - UI and keyboard
tags:
  - key
---
