---
title: Gem
categories:
  - Shapes
tags:
  - shape
  - diamond
---
