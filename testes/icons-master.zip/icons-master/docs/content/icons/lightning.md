---
title: Lightning
categories:
  - Misc
tags:
  - weather
  - storm
  - thunder
  - bolt
---
