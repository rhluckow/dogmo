---
title: Dot
categories:
  - UI and keyboard
tags:
  - middot
---
