---
title: Soundwave
categories:
  - Media
tags:
  - audio
  - sound
  - wave
---
