---
title: Person bounding box
categories:
  - People
tags:
  - human
  - individual
  - avatar
  - crop
---
