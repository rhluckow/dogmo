---
title: Alert triangle fill
categories:
  - Alerts, warnings, and signs
tags:
  - alert
  - warning
---
