---
title: Subtract
categories:
  - Graphics
tags:
  - graphics
  - vector
  - merge
  - layers
---
