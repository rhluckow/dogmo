---
title: Option
categories:
  - UI and keyboard
tags:
  - key
  - mac
---
