---
title: File earmark text
categories:
  - Files and folders
tags:
  - doc
  - document
---
