---
title: Paperclip
categories:
  - Real world
tags:
  - attachment
---
