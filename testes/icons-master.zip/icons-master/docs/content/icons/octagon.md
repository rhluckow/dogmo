---
title: Octagon
categories:
  - Shapes
tags:
  - shape
  - polygon
---
