---
title: Cursor
categories:
  - Geo
tags:
  - pointer
---
