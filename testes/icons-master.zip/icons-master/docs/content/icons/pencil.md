---
title: Pencil
categories:
  - Tools
tags:
  - edit
  - write
---
