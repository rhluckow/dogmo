---
title: Pause
categories:
  - Media
tags:
  - audio
  - video
  - av
---
