---
title: Heart fill
categories:
  - Shapes
tags:
  - love
  - favorite
---
