---
title: Newspaper
categories:
  - Real world
tags:
  - news
  - paper
---
