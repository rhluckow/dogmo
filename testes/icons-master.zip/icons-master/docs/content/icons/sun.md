---
title: Sun
categories:
  - Real world
tags:
  - solar
  - weather
---
