---
title: Laptop
categories:
  - Devices
tags:
  - computer
---
