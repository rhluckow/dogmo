---
title: File rich text
categories:
  - Files and folders
tags:
  - doc
  - document
  - richtext
---
