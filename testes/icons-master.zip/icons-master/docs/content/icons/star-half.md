---
title: Star half fill
categories:
  - Shapes
tags:
  - shape
  - like
  - favorite
---
