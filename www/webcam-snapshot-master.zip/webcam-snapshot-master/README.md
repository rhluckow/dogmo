# Exemplo de como tirar uma foto usando a Webcam com HTML5 e PHP

[![N|Solid](https://velhobit.com.br/wp-content/themes/vale/images/logo-velho-bit.jpg)](https://velhobit.com.br)

**Código fonte usado no post vinculado abaixo. É um exemplo de como utilizar a webcam para tirar fotos em uma aplicação web e armazenar no servidor em formato JPG.**

Para mais detalhes e informações, acesse: https://velhobit.com.br/programacao/como-tirar-uma-foto-usando-a-webcam-javascript-html.html
