Você precisa mudar o save_photos.php se você deseja que seja salvado em outra pasta ou estrutura diferente
You need to change save_photos.php if you wish to save the images inside another folder or tree
